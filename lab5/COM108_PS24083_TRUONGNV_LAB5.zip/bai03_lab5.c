#include <stdio.h>
#include <stdlib.h>
// mssv: ps24083
// truongnv
// ngay tao 23/11/2021
// hoan vi 2 so
int hoanVi(int *a, int *b){
	int dem;
	dem=*b;
	*b=*a;
	*a=dem;
	
	
}
